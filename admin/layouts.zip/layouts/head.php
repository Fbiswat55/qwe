<meta charset="utf-8"/>
<meta name="description" content="APIServer | Tool quản trị tweak ios" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<meta name = "keywords" content = "Hack Pubg, Hack Pubgm, Hack Pubg mobile, Hack LQMB, Hack Liên Quân, Hack Tốc Chiến, Hack LMHT Tốc Chiến, Hack Play Together, hack speed Play together, Hack CODm, Hack Call of duty,
    antiban pubg, antiban LQMB, antiban liên quân, antiban tốc chiến, antiban codm, Hack Pubg free, Hack LQMB free, keyserver, theos, ios
    "/>
<meta content="Bao Nguyen" name="author"/>
<!-- App favicon -->
<link rel="shortcut icon" href="assets/images/favicon.ico">