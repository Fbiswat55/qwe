<li class="menu-title mt-2" data-key="t-components">Admin</li>

<li>
    <a href="admin-list-device.php">
        <i data-feather="smartphone"></i>
        <span data-key="t-horizontal">Admin List Device</span>
    </a>
</li>
<li>
    <a href="admin-list-key.php">
        <i data-feather="key"></i>
        <span data-key="t-horizontal"> Admin List Key</span>
    </a>
</li>
<li>
    <a href="admin-list-deb.php">
        <i data-feather="package"></i>
        <span data-key="t-horizontal">Admin List Package</span>
    </a>
</li>
<li>
    <a href="admin-list-member.php">
        <i data-feather="users"></i>
        <span data-key="t-horizontal">Admin List Member</span>
    </a>
</li>
<li>
    <a href="admin-list-post.php">
        <i data-feather="file-text"></i>
        <span data-key="t-horizontal">Admin List Post</span>
    </a>
</li>
<li>
    <a href="admin-server.php">
        <i data-feather="server"></i>
        <span data-key="t-horizontal">Configuration Server</span>
    </a>
</li>