<?php
// Initialize the session
session_start();
require_once('config.php');
// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: auth-login.php");
    exit;
}

if (!$settings_status && $_SESSION['level'] != 1) {
    header("location: pages-maintenance.php");
    exit;
}

$email = $_SESSION['email'];
$acc = "SELECT * FROM tai_khoan WHERE email = '$email'";
$result_acc = mysqli_query($conn, $acc);
$row_acc = mysqli_fetch_array($result_acc);

function basic_keygen ($level) {
    if($level == 2) {
      $keygen_basic = $_SESSION["username"] . '-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
      return $keygen_basic;
    }else {
        $keygen_basic = 'baontq-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
        return $keygen_basic;
    }
}

function days_keygen ($level) {
    if($level == 2) {
      $keygen_basic = $_SESSION["username"] . '-days-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
      return $keygen_basic;
    }else {
        $keygen_basic = 'baontq-days-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
        return $keygen_basic;
    }
}

function month_keygen ($level) {
    if($level == 2) {
      $keygen_basic = $_SESSION["username"] . '-month-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
      return $keygen_basic;
    }else {
        $keygen_basic = 'baontq-month-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
        return $keygen_basic;
    }
}

function year_keygen ($level) {
    if($level == 2) {
      $keygen_basic = $_SESSION["username"] . '-year-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
      return $keygen_basic;
    }else {
        $keygen_basic = 'baontq-year-' . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyz"), 0, 16);
        return $keygen_basic;
    }
}
